#include "pivot.h"

pivot::pivot(){}
