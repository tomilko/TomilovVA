#ifndef GLOBAL_H
#define GLOBAL_H
extern double percent;
extern double sum;
extern double vklad;

class global
{
public:
    global();
};

#endif // GLOBAL_H
