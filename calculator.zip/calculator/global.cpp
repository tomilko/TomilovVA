#include "global.h"
double percent=0;
double sum=0;
double vklad;
global::global()
{

}
