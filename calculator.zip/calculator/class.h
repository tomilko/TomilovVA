#ifndef EXTERN_H
#define EXTERN_H
extern int year;
extern double percent;

class extern
{
public:
    extern();
};

#endif // class_H
