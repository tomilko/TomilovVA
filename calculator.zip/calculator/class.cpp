#include "class.h"

extern int year;
extern double percent;

extern::extern()
{

}
